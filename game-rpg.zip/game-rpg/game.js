// ================= SETUP =================
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

canvas.width = 1600;
canvas.height = 900;

// UI
const menu = document.getElementById("menu");
const gameOverScreen = document.getElementById("gameOverScreen");
const playBtn = document.getElementById("playBtn");
const restartBtn = document.getElementById("restartBtn");
const attackBtn = document.getElementById("attackBtn");

// IMAGES
const playerImg = new Image();
playerImg.src = "player.png";

const monsterImg = new Image();
monsterImg.src = "monster.png";

const houseImg = new Image();
houseImg.src = "house.png";

const treeImg = new Image();
treeImg.src = "tree.png";

// MAP SIZE
const mapWidth = 3000;
const mapHeight = 2000;

// PLAYER
let player = {
  x: 1500,
  y: 1000,
  size: 64,
  speed: 4,
  hp: 100,
  maxHp: 100
};

// CONTROLS
let keys = {};
let joystick = { x: 0, y: 0 };

// STATE
let gameStarted = false;
let gameOver = false;

// CAMERA
let camX = 0;
let camY = 0;

// OBJEK MAP
const houses = [
  { x: 400, y: 400 },
  { x: 2500, y: 500 }
];

const trees = [
  { x: 800, y: 800 },
  { x: 1200, y: 600 },
  { x: 1800, y: 900 }
];

// MONSTERS
let monsters = [];

function spawnMonster() {
  if (monsters.length >= 3) return;

  monsters.push({
    x: Math.random() * mapWidth,
    y: Math.random() * mapHeight,
    size: 64,
    hp: 50,
    speed: 1.5,
    lastHit: 0
  });
}

// KEYBOARD
document.addEventListener("keydown", e => keys[e.key] = true);
document.addEventListener("keyup", e => keys[e.key] = false);

// JOYSTICK
const joy = document.getElementById("joystick");
const stick = document.getElementById("stick");
let joyActive = false;

joy.addEventListener("touchstart", () => joyActive = true);

joy.addEventListener("touchend", () => {
  joyActive = false;
  joystick.x = 0;
  joystick.y = 0;
  stick.style.left = "40px";
  stick.style.top = "40px";
});

joy.addEventListener("touchmove", e => {
  if (!joyActive) return;

  let r = joy.getBoundingClientRect();
  let x = e.touches[0].clientX - r.left - 70;
  let y = e.touches[0].clientY - r.top - 70;

  let dist = Math.sqrt(x*x + y*y);
  if (dist > 50) {
    x = (x / dist) * 50;
    y = (y / dist) * 50;
  }

  stick.style.left = (x + 70 - 30) + "px";
  stick.style.top  = (y + 70 - 30) + "px";

  joystick.x = x / 50;
  joystick.y = y / 50;
});

// BUTTON
attackBtn.onclick = () => attackMonster();

playBtn.onclick = startGame;
restartBtn.onclick = restartGame;

// ATTACK
function attackMonster() {
  monsters.forEach((m, i) => {
    let dx = m.x - player.x;
    let dy = m.y - player.y;
    let dist = Math.sqrt(dx*dx + dy*dy);

    if (dist < 100) {
      m.hp -= 10;
      if (m.hp <= 0) monsters.splice(i, 1);
    }
  });
}

// GAME FLOW
function startGame() {
  menu.style.display = "none";
  gameOverScreen.style.display = "none";
  gameStarted = true;
  gameOver = false;
  loop();
}

function restartGame() {
  gameOverScreen.style.display = "none";
  monsters = [];
  player.hp = 100;
  startGame();
}

// MAIN LOOP
function loop() {
  if (!gameStarted || gameOver) return;

  update();
  draw();

  requestAnimationFrame(loop);
}

// UPDATE
function update() {
  // WALK
  if (keys["ArrowUp"] || keys["w"]) player.y -= player.speed;
  if (keys["ArrowDown"] || keys["s"]) player.y += player.speed;
  if (keys["ArrowLeft"] || keys["a"]) player.x -= player.speed;
  if (keys["ArrowRight"] || keys["d"]) player.x += player.speed;

  player.x += joystick.x * player.speed;
  player.y += joystick.y * player.speed;

  // LIMIT MAP
  player.x = Math.max(0, Math.min(mapWidth - player.size, player.x));
  player.y = Math.max(0, Math.min(mapHeight - player.size, player.y));

  // CAMERA
  camX = player.x - canvas.width / 2 + player.size / 2;
  camY = player.y - canvas.height / 2 + player.size / 2;

  camX = Math.max(0, Math.min(mapWidth - canvas.width, camX));
  camY = Math.max(0, Math.min(mapHeight - canvas.height, camY));

  // MONSTER SPAWN
  if (Math.random() < 0.01) spawnMonster();

  // MONSTER AI
  monsters.forEach(m => {
    let dx = player.x - m.x;
    let dy = player.y - m.y;
    let dist = Math.sqrt(dx*dx + dy*dy);

    if (dist < 300) {
      m.x += (dx / dist) * m.speed;
      m.y += (dy / dist) * m.speed;
    }

    if (dist < 60) {
      if (Date.now() - m.lastHit > 1000) {
        player.hp -= 5;
        m.lastHit = Date.now();

        if (player.hp <= 0) {
          gameOver = true;
          gameOverScreen.style.display = "flex";
        }
      }
    }
  });
}

// DRAW
function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // GROUND
  ctx.fillStyle = "#5DBB63";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // HOUSES
  houses.forEach(h => {
    ctx.drawImage(houseImg, h.x - camX, h.y - camY, 100, 100);
  });

  // TREES
  trees.forEach(t => {
    ctx.drawImage(treeImg, t.x - camX, t.y - camY, 80, 80);
  });

  // MONSTERS
  monsters.forEach(m => {
    ctx.drawImage(monsterImg, m.x - camX, m.y - camY, m.size, m.size);

    // HP bar monster
    ctx.fillStyle = "red";
    ctx.fillRect(m.x - camX, m.y - camY - 10, (m.hp / 50) * 60, 6);
  });

  // PLAYER
  ctx.drawImage(playerImg, player.x - camX, player.y - camY, player.size, player.size);

  // HP bar player
  ctx.fillStyle = "black";
  ctx.fillRect(20, 20, 200, 20);
  ctx.fillStyle = "lime";
  ctx.fillRect(20, 20, (player.hp / player.maxHp) * 200, 20);
}
